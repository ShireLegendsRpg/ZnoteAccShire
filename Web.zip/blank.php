<?php require_once 'engine/init.php'; include 'layout/overall/header.php'; ?>

<h1>Blank</h1>
<p>This is a blank sample page.</p>

<?php include 'layout/overall/footer.php'; ?>